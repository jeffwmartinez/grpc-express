# gRPC node app

#### How to install the application locally

#### How the app works

#### Current Issues on App Service
1. When deployed to App Service the application doesn't work


#### Logs

### Steps to run the application
#### 1. Clone the application and open the `ExpressApp1` app in Visual Studio or VS Code

#### 2. Clone the gRPC node client app
To see the app in action, you will also need to clone the [client repository](https://github.com/jeffwmartinez/grpc-node-client)

#### 3. Run the app locally
To run this app locally, use Ctrl+F5 to start the app.  A console will open and the gRPC service will start listening on port `8383`.

The browser will also launch w/ express and start listening on http://localhost:1337.  The server app is now ready to receive requests from the `grpc-client-node` app found in this repo.

#### Start the client application
Once the application is running, you can start the client application.  Open the client application and run it using Ctrl+F5.

The client app will open a console app and respond with the text "Greeting: Hello World"


#### Deploying to App Service
Now that it's tested locally, you can deploy the application to App Service.  Create a web app using the following directions in this [How-To](https://github.com/Azure/app-service-linux-docs/blob/master/HowTo/gRPC/use_gRPC_with_dotnet.md#deploy-to-app-service) to enable gRPC calls.

Once it's deployed, you can replace the listening port in the local client application with the azurewebsites.net url to test the deployed grpc server.

#### Issues
1. Once deployed, the application serves an "Application Error" page.
2. 




